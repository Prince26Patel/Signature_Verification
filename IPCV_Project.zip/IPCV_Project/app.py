import os
import cv2
import streamlit as st
from skimage.metrics import structural_similarity as ssim
from PIL import Image
import numpy as np

THRESHOLD = 80

def match(image1, image2):
    """
    Compare two images and calculate their similarity using Structural Similarity Index (SSIM).
    """
    # Convert images to grayscale
    img1_gray = cv2.cvtColor(image1, cv2.COLOR_BGR2GRAY)
    img2_gray = cv2.cvtColor(image2, cv2.COLOR_BGR2GRAY)

    # Resize images for comparison
    img1_resized = cv2.resize(img1_gray, (300, 300))
    img2_resized = cv2.resize(img2_gray, (300, 300))

    # Calculate SSIM similarity
    similarity_value = ssim(img1_resized, img2_resized) * 100
    similarity_value = round(similarity_value, 2)

    return similarity_value

def check_similarity(image1, image2):
    """Compare the similarity between two signatures."""
    similarity = match(image1, image2)
    if similarity <= THRESHOLD:
        return f"Failure: Signatures Do Not Match. They are {similarity}% similar!", similarity
    else:
        return f"Success: Signatures Match! They are {similarity}% similar!", similarity

st.title("IPCV Project - Signature Matching Tool")

st.subheader("Signature 1")
sig1_file = st.file_uploader("Upload Signature 1", type=["jpg", "png", "jpeg"], key="sig1")

st.subheader("Signature 2")
sig2_file = st.file_uploader("Upload Signature 2", type=["jpg", "png", "jpeg"], key="sig2")

if sig1_file and sig2_file:
    sig1_image = np.array(Image.open(sig1_file))
    sig2_image = np.array(Image.open(sig2_file))

    col1, col2 = st.columns(2)
    with col1:
        st.image(sig1_image, caption="Signature 1", width=300)
    with col2:
        st.image(sig2_image, caption="Signature 2", width=300)

    sig1_bgr = cv2.cvtColor(sig1_image, cv2.COLOR_RGB2BGR)
    sig2_bgr = cv2.cvtColor(sig2_image, cv2.COLOR_RGB2BGR)

    if st.button("Compare Signatures"):
        result_message, similarity = check_similarity(sig1_bgr, sig2_bgr)
        st.write(f"**Result:** {result_message}")
        
        if similarity >= 80:
            st.markdown(
                f'<div style="background-color:green; padding:10px; border-radius:5px; color:white; text-align:center;">Similarity: {similarity}%</div>', 
                unsafe_allow_html=True
            )
        elif 50 <= similarity < 80:
            st.markdown(
                f'<div style="background-color:yellow; padding:10px; border-radius:5px; color:black; text-align:center;">Similarity: {similarity}%</div>', 
                unsafe_allow_html=True
            )
        else:
            st.markdown(
                f'<div style="background-color:red; padding:10px; border-radius:5px; color:white; text-align:center;">Similarity: {similarity}%</div>', 
                unsafe_allow_html=True
            )
else:
    st.info("Please upload both Signature 1 and Signature 2 to compare.")

st.markdown("---")
st.markdown("Developed by Vibhu Mishra, Priyanshu Chaturvedi & Prince Patel")